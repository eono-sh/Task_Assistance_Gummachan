#!bin/bash
sleep 10
mpg321 /home/pi/jyuryoudo.mp3
sleep 15
mpg321 /home/pi/cameramojyuru2.mp3
